<?php

class Playlists
{
    private $conn;
    private $id;
    private $title;
    private $description;
    private $status;
    private $tutorId;
    private $thumb;
    private $date;

    public function __construct($conn, $id, $title, $description, $status, $tutorId, $thumb, $date) {
        $this->conn = $conn;
        $this->id = $id;
        $this->title = $title;
        $this->description = $description;
        $this->status = $status;
        $this->tutorId = $tutorId;
        $this->thumb = $thumb;
        $this->date = $date;
    }


    public function getAllPlaylists()
    {
        $playlists = [];

        $select_playlists = $this->conn->prepare("SELECT * FROM playlist WHERE status = ? ORDER BY date DESC LIMIT 6");
        $select_playlists->execute(['active']);

        if ($select_playlists->rowCount() > 0) {
            while ($fetch_playlist = $select_playlists->fetch(PDO::FETCH_ASSOC)) {
                $playlist = $this->preparePlaylistDetails($fetch_playlist);
                $playlists[] = $playlist;
            }
        }

        return $playlists;
    }
    public function createPlaylist($tutorId, $title, $description, $thumb, $status)
    {
        $id = unique_id();

        $add_playlist = $this->conn->prepare("INSERT INTO playlist (id, tutor_id, title, description, thumb, status) VALUES (?, ?, ?, ?, ?, ?)");
        $add_playlist->execute([$id, $tutorId, $title, $description, $thumb, $status]);

        return $id;
}


    public function getPlaylistById($playlistId)
    {
        $select_playlist = $this->conn->prepare("SELECT * FROM playlist WHERE id = ?");
        $select_playlist->execute([$playlistId]);

        if ($select_playlist->rowCount() > 0) {
            $fetch_playlist = $select_playlist->fetch(PDO::FETCH_ASSOC);
            return $this->preparePlaylistDetails($fetch_playlist);
        }

        return null;
    }

    private function preparePlaylistDetails($playlistData)
    {
        $playlistId = $playlistData['id'];

        $select_tutor = $this->conn->prepare("SELECT * FROM tutors WHERE id = ?");
        $select_tutor->execute([$playlistData['tutor_id']]);
        $fetch_tutor = $select_tutor->fetch(PDO::FETCH_ASSOC);

        return [
            'id' => $playlistId,
            'tutor' => [
                'id' => $fetch_tutor['id'],
                'name' => $fetch_tutor['name'],
                'image' => $fetch_tutor['image'],
            ],
            'date' => $playlistData['date'],
            'thumb' => $playlistData['thumb'],
            'title' => $playlistData['title'],
    ];
}
}

?>