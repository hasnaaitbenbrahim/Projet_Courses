<?php

class Teachers
{
        private $conn;
        private $name;
        private $profession;
        private $email;
        private $password;
        private $image;
    
        public function __construct($conn, $name, $profession, $email, $password, $image) {
            $this->conn = $conn;
            $this->name = $name;
            $this->profession = $profession;
            $this->email = $email;
            $this->password = $password;
            $this->image = $image;
        }

    public function getAllTutors()
    {
        $tutors = [];

        $select_tutors = $this->conn->prepare("SELECT * FROM tutors");
        $select_tutors->execute();

        if ($select_tutors->rowCount() > 0) {
            while ($fetch_tutor = $select_tutors->fetch(PDO::FETCH_ASSOC)) {
                $tutor = $this->prepareTutorDetails($fetch_tutor);
                $tutors[] = $tutor;
            }
        }

        return $tutors;
    }

    public function getTutorById($tutorId)
    {
        $select_tutor = $this->conn->prepare("SELECT * FROM tutors WHERE id = ?");
        $select_tutor->execute([$tutorId]);

        if ($select_tutor->rowCount() > 0) {
            $fetch_tutor = $select_tutor->fetch(PDO::FETCH_ASSOC);
            return $this->prepareTutorDetails($fetch_tutor);
        }

        return null;
    }

    private function prepareTutorDetails($tutorData)
    {
        $tutorId = $tutorData['id'];

        $count_playlists = $this->conn->prepare("SELECT * FROM playlist WHERE tutor_id = ?");
        $count_playlists->execute([$tutorId]);
        $total_playlists = $count_playlists->rowCount();

        $count_contents = $this->conn->prepare("SELECT * FROM content WHERE tutor_id = ?");
        $count_contents->execute([$tutorId]);
        $total_contents = $count_contents->rowCount();

        return [
            'id' => $tutorId,
            'name' => $tutorData['name'],
            'profession' => $tutorData['profession'],
            'image' => $tutorData['image'],
            'total_playlists' => $total_playlists,
            'total_contents' => $total_contents,
    ];
}
}

?>
