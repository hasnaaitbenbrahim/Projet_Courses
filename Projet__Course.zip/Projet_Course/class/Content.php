<?php

class Content
{
    private $id;
    private $conn;
    private $title;
    private $status;
    private $description;
    private $playlist;
    private $video;
    private $tutor_id;
    private $thumb; 


    public function __construct($conn, $id, $title, $status, $description, $playlist, $video, $tutor_id, $thumb) {
        $this->conn = $conn;
        $this->id = $id;
        $this->title = $title;
        $this->status = $status;
        $this->description = $description;
        $this->playlist = $playlist;
        $this->video = $video;
        $this->tutor_id = $tutor_id;
        $this->thumb = $thumb;
    }

    public function getAllCourses()
    {
        $courses = [];

        $select_courses = $this->conn->prepare("SELECT * FROM playlist WHERE status = ? ORDER BY date DESC");
        $select_courses->execute(['active']);

        if ($select_courses->rowCount() > 0) {
            while ($fetch_course = $select_courses->fetch(PDO::FETCH_ASSOC)) {
                $course = $this->prepareCourseDetails($fetch_course);
                $courses[] = $course;
            }
        }

        return $courses;
    }

    public function getCourseById($courseId)
    {
        $select_course = $this->conn->prepare("SELECT * FROM playlist WHERE id = ?");
        $select_course->execute([$courseId]);

        if ($select_course->rowCount() > 0) {
            $fetch_course = $select_course->fetch(PDO::FETCH_ASSOC);
            return $this->prepareCourseDetails($fetch_course);
        }

        return null;
    }

    private function prepareCourseDetails($courseData)
    {
        $courseId = $courseData['id'];
        $tutorId = $courseData['tutor_id'];

        $select_tutor = $this->conn->prepare("SELECT * FROM tutors WHERE id = ?");
        $select_tutor->execute([$tutorId]);

        if ($select_tutor->rowCount() > 0) {
            $fetch_tutor = $select_tutor->fetch(PDO::FETCH_ASSOC);

            return [
                'id' => $courseId,
                'tutor' => [
                    'id' => $fetch_tutor['id'],
                    'name' => $fetch_tutor['name'],
                    'image' => $fetch_tutor['image'],
                ],
                'date' => $courseData['date'],
                'thumb' => $courseData['thumb'],
                'title' => $courseData['title'],
            ];
        }

        return null;
    }
}

?>